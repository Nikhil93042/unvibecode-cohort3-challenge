# node-jsonwebtoken — Context for AI

3 workflows · 0 risk findings · 50 verified connections · 69 code sections

Attach this file and `chunks.jsonl` together. Every code reference below identifies a source section in `chunks.jsonl`.

## 1. Business workflows

### 1. Decode a JWT.

Workflow ID: `business_path_ab353ae1c875a89a`

A caller invokes the exported decode function with a JWT; the function delegates decoding, optionally parses a JSON payload, and returns the payload or complete decoded components.

**Purpose:** Obtain a token's payload, optionally with its header and signature.

**Business outcome**

- Provides decoded token content to the caller.
- Complete mode exposes header and signature alongside the payload.

**Important behavior and rules**

- A string payload is parsed as JSON when parsing succeeds and produces a non-null object; otherwise the original payload remains.
- Complete decoded output is selected only when the complete option is exactly true.
- If jws.decode returns a falsy result, decode returns null.
- The header/payload/signature object is returned only when options.complete is exactly true.

**Identified functions:** `index.js exported decode`, `decode.js module.exports function`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| module.exports decode function | `decode.js` | `chunk_9a516c15ac29b962` |
| module.exports | `index.js` | `chunk_d46ca2ccebc444b8` |

### 2. Sign JWT payloads

Workflow ID: `business_path_0ca355077a9a97c1`

A caller supplies a payload and signing key to sign.js; the library validates inputs and key/algorithm compatibility, applies configured claims and timestamps, and returns a JWS signature.

**Purpose:** Create a signed token for use by a caller

**Business outcome**

- Produces a signed token string or callback result for caller use.

**Important behavior and rules**

- For asymmetric signing algorithms, key type and (unless explicitly allowed) algorithm-specific asymmetric key details are validated.
- A payload that already contains exp or nbf cannot also receive the corresponding expiresIn or notBefore option.
- Signing requires key material unless algorithm is none; key type must match the selected algorithm family.
- Payload and options are validated, and conflicting existing exp/nbf claims with corresponding options are rejected.

**Identified functions:** `sign.js module.exports(payload, secretOrPrivateKey, options, callback)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `sign.js` | `chunk_9938ec4185be0de4` |
| module.exports | `lib/validateAsymmetricKey.js` | `chunk_a38043514aa004fb` |
| Source section | `sign.js` | `chunk_ae0e4d2c85290ef4` |
| Source section | `sign.js` | `chunk_b0032c4bbcd9d393` |
| Source section | `sign.js` | `chunk_b8da171996e8269a` |
| Source section | `sign.js` | `chunk_dbc7bc798536766f` |
| Source section | `sign.js` | `chunk_e10989b30f812f0d` |

### 3. Verify JWTs and validate claims

Workflow ID: `business_path_c0e61ef0b5793f14`

A caller supplies a JWT and key material to verify.js; the library verifies signature and applicable claims, then returns payload or complete token data, or reports an error.

**Purpose:** Determine whether a supplied token satisfies signature and configured claim checks and retrieve its payload

**Business outcome**

- Returns payload or complete decoded token on successful checks; otherwise reports verification error.

**Important behavior and rules**

- A token with a signature must have key material; unsigned tokens require explicit inclusion of none in algorithms when no signature is present.
- A token is returned only after signature verification succeeds and configured claim checks pass.
- When configured, audience, issuer, subject, jwtid, and nonce must match the supplied expected values.
- Expiration and maximum-age checks use clockTimestamp (or current time) with configured clockTolerance; ignore options can bypass nbf or exp checks.
- Token must be supplied as a string with three dot-separated parts and decode to a token.
- The token algorithm must be allowed by options or the key-derived algorithm list; key type and asymmetric key details are checked.
- Configured nbf, exp, audience, issuer, subject, jwtid, nonce, and maxAge constraints are checked before successful return.

**Identified functions:** `verify.js module.exports(jwtString, secretOrPublicKey, options, callback)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `verify.js` | `chunk_34e825890731b45f` |
| module.exports | `lib/validateAsymmetricKey.js` | `chunk_a38043514aa004fb` |

## 2. Verified code connections and remaining repository context

Connections are static source relationships; they do not prove runtime execution.

- `chunk_0e16dc54d0b5d06c` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_0e16dc54d0b5d06c` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_134e72b47f589a5e` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_134e72b47f589a5e` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_1aea3b0af7f45ac6` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_1aea3b0af7f45ac6` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_0204d1ab5c448b7e`: imports_module; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_0204d1ab5c448b7e`: file_import; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_1e42bbaec12770e3`: imports_module; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_1e42bbaec12770e3`: file_import; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_277865c4e83f00d5`: imports_module; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_277865c4e83f00d5`: file_import; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_9a516c15ac29b962`: imports_module; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_9a516c15ac29b962`: file_import; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_a38043514aa004fb`: imports_module; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_a38043514aa004fb`: file_import; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_ae9ecd78619d3680`: imports_module; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_ae9ecd78619d3680`: file_import; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_e9d8e2f23f603b81`: imports_module; symbol: not specified
- `chunk_34e825890731b45f` → `chunk_e9d8e2f23f603b81`: file_import; symbol: not specified
- `chunk_414297b6846201d9` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_414297b6846201d9` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_4cdea770aba0bcf2` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_4cdea770aba0bcf2` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_52d33458ca9259b2` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_52d33458ca9259b2` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_62e5bc1bb638afd7` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_62e5bc1bb638afd7` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_70be1f0bdf3bc953` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_70be1f0bdf3bc953` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_7eb6ffab2b22a539` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_7eb6ffab2b22a539` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_a38043514aa004fb` → `chunk_0769d5d83b374778`: imports_module; symbol: not specified
- `chunk_a38043514aa004fb` → `chunk_0769d5d83b374778`: file_import; symbol: not specified
- `chunk_a38043514aa004fb` → `chunk_acfe34903f1fe970`: imports_module; symbol: not specified
- `chunk_a38043514aa004fb` → `chunk_acfe34903f1fe970`: file_import; symbol: not specified
- `chunk_ae9ecd78619d3680` → `chunk_0204d1ab5c448b7e`: imports_module; symbol: not specified
- `chunk_ae9ecd78619d3680` → `chunk_0204d1ab5c448b7e`: file_import; symbol: not specified
- `chunk_ba03bedae17f93ce` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_ba03bedae17f93ce` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_cd744c5cd7f9dcc6` → `chunk_1e42bbaec12770e3`: imports_module; symbol: not specified
- `chunk_cd744c5cd7f9dcc6` → `chunk_1e42bbaec12770e3`: file_import; symbol: not specified
- `chunk_cd744c5cd7f9dcc6` → `chunk_277865c4e83f00d5`: imports_module; symbol: not specified
- `chunk_cd744c5cd7f9dcc6` → `chunk_277865c4e83f00d5`: file_import; symbol: not specified
- `chunk_cd744c5cd7f9dcc6` → `chunk_a38043514aa004fb`: imports_module; symbol: not specified
- `chunk_cd744c5cd7f9dcc6` → `chunk_a38043514aa004fb`: file_import; symbol: not specified
- `chunk_dc1950b7b4899652` → `chunk_7b9ed448629449a1`: imports_module; symbol: not specified
- `chunk_dc1950b7b4899652` → `chunk_7b9ed448629449a1`: file_import; symbol: not specified
- `chunk_e9d8e2f23f603b81` → `chunk_0204d1ab5c448b7e`: imports_module; symbol: not specified
- `chunk_e9d8e2f23f603b81` → `chunk_0204d1ab5c448b7e`: file_import; symbol: not specified

Other source sections remain available in `chunks.jsonl`; code is stored only once.

## 3. Business risks

Analysis status: **NO_REPORTABLE_FINDINGS**

No reportable risk findings. This does not mean the repository is risk-free.
